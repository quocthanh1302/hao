#!/bin/bash

WORK_DIR="/hive/miners/custom/apoolminer_hiveos_qubic_aleo_idle_mining"
LOG_FILE="$WORK_DIR/.monitor.log"
EPOCH_CHALLENGE_URL="http://qubic1.hk.apool.io:8001/api/qubic/epoch_challenge"

cd "$WORK_DIR" || { echo "Failed to change directory to $WORK_DIR"; exit 1; }

log() {
    echo "$(date +"%Y-%m-%d %H:%M:%S") $1" >> "$LOG_FILE"
}

terminate_script() {
    log "Exiting script."
    pkill -9 -f monitor.sh
    exit 0
}

if ! pgrep -x "h-run.sh" > /dev/null; then
    log "h-run.sh is not running. Exiting script."
    terminate_script
fi

monitor_process() {
    while true; do
        if ! pgrep -x "h-run.sh" > /dev/null; then
            log "h-run.sh has stopped running. Exiting script."
            terminate_script
        fi
        sleep 15
    done
}

check_for_updates() {
    local last_response=""

    while true; do
        response=$(curl -s "$EPOCH_CHALLENGE_URL" | grep -o '"mining_seed":"[^"]*"' | sed 's/.*"mining_seed":"\([^"]*\)".*/\1/')

        if [[ -z "$response" ]]; then
            log "Failed to get response from $EPOCH_CHALLENGE_URL. Retry script."
        fi

        log "Received mining seed: $response"

        if [[ "$response" != "$last_response" ]]; then
            last_response="$response" 

            log "Detected new mining seed: $response. Restarting miner..."
            /hive/bin/miner restart
            sleep 5
            /hive/bin/miner start
            sleep 5

            log "Miner restarted successfully."
        else
            log "No new mining seed detected. Skipping restart."
        fi

        sleep 30
    done
}

monitor_process &
check_for_updates
